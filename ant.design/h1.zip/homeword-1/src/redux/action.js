import {addStaff,modifyStaff,deleteStaff,search} from './staffList'

export {addStaff,modifyStaff,deleteStaff,search}