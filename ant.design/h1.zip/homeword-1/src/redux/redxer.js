import {staffReducer} from './staffList'

export {staffReducer}